import pandas as pd
import tkinter as tk
from tkinter import filedialog
import tkinter.font as tkFont
import pyodbc

#Insert into user before manager, employee, or customer
#Customer, Manager, Employee, Vehicles, Insurance, Repairs, Tasks


# def openFile(inserter):
#     global myExcelFile
#     myExcelFile = filedialog.askopenfilename(title="Open file okay?",filetypes=[("Excel files", ".xlsx .xls")])
#     inserter.set(myExcelFile)

def mySwitcher(arguement:str):
    switcher = {
        "Insurance": ["ClaimNumber","PolicyNumber","Deductible"],
        "Customer":["Username","NumberOfVisits"],
        "Employee":["Username"],
        "Manager":["Username"],
        "Part":["PartNumber","Name","Price"],
        "Repair":["StartDate","EndDate","Description","Discount","TotalCost","Completion"],
        "Task":["Name","Description","Price","Completion"],
        "User":["Username","HashPass","SaltPass","UserType","FirstName","LastName"],
        "Vehicle":["VIN","Year","Model","Mileage","BodyType"]
    }
    return switcher.get(arguement)

def executeFile(myExcelField:str):
    if(len(myExcelField) == 0):
        print("Incorrect")
    else:
        # Import CSV
        insuranceData = pd.read_excel(myExcelField,sheet_name="Insurance")
        insurancedf = pd.DataFrame(insuranceData, columns= mySwitcher("Insurance"))

        customerData = pd.read_excel(myExcelField,sheet_name="Customer")
        customerdf = pd.DataFrame(customerData, columns= mySwitcher("Customer"))

        employeeData = pd.read_excel(myExcelField,sheet_name="Employee")
        employeedf = pd.DataFrame(employeeData, columns= mySwitcher("Employee"))

        managerData = pd.read_excel(myExcelField,sheet_name="Manager")
        managerdf = pd.DataFrame(managerData, columns= mySwitcher("Manager"))

        partData = pd.read_excel(myExcelField,sheet_name="Part")
        partdf = pd.DataFrame(partData, columns= mySwitcher("Part"))

        repairData = pd.read_excel(myExcelField,sheet_name="Repair")
        repairdf = pd.DataFrame(repairData, columns= mySwitcher("Repair"))

        taskData = pd.read_excel(myExcelField,sheet_name="Task")
        taskdf = pd.DataFrame(taskData, columns= mySwitcher("Task"))

        userData = pd.read_excel(myExcelField,sheet_name="User")
        userdf = pd.DataFrame(userData, columns= mySwitcher("User"))

        vehicleData = pd.read_excel(myExcelField,sheet_name="Vehicle")
        vehicledf = pd.DataFrame(vehicleData, columns= mySwitcher("Vehicle"))


        # # Connect to SQL Server
        conn = pyodbc.connect('Driver={SQL Server};'
                              'Server=titan.csse.rose-hulman.edu;'
                              'Database=AutoRepairShop_S2G2;'
                              "uid=emilyTestARS;pwd=basicPass!")
        cursor = conn.cursor()

        # # Insert DataFrame to Table
        for row in insurancedf.itertuples():
                cursor.execute(f"INSERT INTO Insurance (ClaimNumber,PolicyNumber,Deductible) VALUES (?,?,?)",
                        row.ClaimNumber, 
                        row.PolicyNumber,
                        row.Deductible
                        )
                conn.commit()
        for row in userdf.itertuples():
                cursor.execute(f"INSERT INTO [User] (Username,HashPass,SaltPass,UserType,FirstName,LastName) VALUES (?,?,?,?,?,?)",
                        row.Username,
                        row.HashPass,
                        row.SaltPass,
                        row.UserType,
                        row.FirstName,
                        row.LastName
                        )
                conn.commit()
        for row in customerdf.itertuples():
                cursor.execute(f"INSERT INTO Customer (Username,NumberOfVisits) VALUES (?,?)",
                        row.Username, 
                        row.NumberOfVisits
                        )
                conn.commit()
        for row in employeedf.itertuples():
                cursor.execute(f"INSERT INTO Employee (Username) VALUES (?)",
                        row.Username
                        )
                conn.commit()
        for row in managerdf.itertuples():
                cursor.execute(f"INSERT INTO Manager (Username) VALUES (?)",
                        row.Username
                        )
                conn.commit()
        for row in partdf.itertuples():
                cursor.execute(f"INSERT INTO Part (PartNumber,Name,Price) VALUES (?,?,?)",
                        row.PartNumber,
                        row.Name,
                        row.Price
                        )
                conn.commit()
        for row in repairdf.itertuples():
                cursor.execute(f"INSERT INTO Repair (StartDate,EndDate,Description,Discount,TotalCost,Completion) VALUES (?,?,?,?,?,?)",
                        row.StartDate,
                        row.EndDate,
                        row.Description,
                        row.Discount,
                        row.TotalCost,
                        row.Completion
                        )
                conn.commit()
        for row in taskdf.itertuples():
                cursor.execute(f"INSERT INTO Task (Name,Description,Price,Completion) VALUES (?,?,?,?)",
                        row.Name,
                        row.Description,
                        row.Price,
                        row.Completion
                        )
                conn.commit()
        for row in vehicledf.itertuples():
                cursor.execute(f"INSERT INTO [Vehicle] (VIN,Year,Model,Mileage,BodyType) VALUES (?,?,?,?,?)",
                        row.VIN,
                        row.Year,
                        row.Model,
                        row.Mileage,
                        row.BodyType
                        )
                conn.commit()
        print('FINISHED')

class DatabaseView(tk.Frame):
    def __init__(self, root):
        tk.Frame.__init__(self, root)
        # global myExcelFile
        fontStyle = tkFont.Font(family="Lucida Grande", size=30)

        mainLabel = tk.Label(master=window,text="Data Import Auto Shop",font=fontStyle)
        mainLabel.grid(row=0,column=0,columnspan=2, padx=10, pady=10)

        excelLabel = tk.Label(master=window,text="Choose excel File").grid(row=1,column=0, padx=10, pady=10)
        excelInserter = tk.StringVar()
        excelEntry = tk.Entry(master=window,text="Exec File Path",textvariable=excelInserter)
        excelEntry.grid(row=1,column=1,columnspan=2, padx=10, pady=10)

        print(excelEntry.get())

        finishedButton = tk.Button(master=window,text="Finished",command=lambda: executeFile(excelInserter.get())).grid(row=5,column=0,columnspan=2, padx=10, pady=10)
            




if __name__=='__main__':
    myExcelFile = ''
    window = tk.Tk()
    view = DatabaseView(window)
    view.grid(row=0,column=0)
    
    window.mainloop()


# # Import CSV
# data = pd.read_excel(r"C:\Users\namburs\Desktop\Parts.xlsx")
# df = pd.DataFrame(data, columns= ['PartNumber','Name','Price'])

# # Connect to SQL Server
# conn = pyodbc.connect('Driver={SQL Server};'
#                       'Server=titan.csse.rose-hulman.edu;'
#                       'Database=AutoRepairShop_S2G2;'
#                       "uid=emilyTestARS;pwd=basicPass!")
# cursor = conn.cursor()

# # Insert DataFrame to Table
# for row in df.itertuples():
#     cursor.execute('''
#                 INSERT INTO Part (PartNumber,Name,Price)
#                 VALUES (?,?,?)
#                 ''',
#                 row.PartNumber, 
#                 row.Name,
#                 row.Price
#                 )
# conn.commit()